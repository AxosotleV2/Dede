﻿namespace Dede.Domain;

public class Class1
{
}