﻿namespace Dede.Service;

public class Class1
{
}