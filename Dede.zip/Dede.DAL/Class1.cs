﻿namespace Dede.DAL;

public class Class1
{
}